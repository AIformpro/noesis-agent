from noesis.core import NoesisAgent

agent = NoesisAgent()
print(agent.run_benchmark("demo"))
