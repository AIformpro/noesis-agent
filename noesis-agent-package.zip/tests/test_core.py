from noesis.core import NoesisAgent

def test_run_benchmark():
    agent = NoesisAgent()
    r = agent.run_benchmark("echo")
    assert r["task"] == "echo" and "score" in r
