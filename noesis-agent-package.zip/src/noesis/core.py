class NoesisAgent:
    def __init__(self):
        self.records = []
    def run_benchmark(self, task):
        result = {"task": task, "score": 1.0}
        self.records.append(result)
        return result
